<div class="left-sidebar">
    <h4>Services</h4>
    <ul>
        <li><a href="tanks.php">Tanks</a>
        </li>
        <li><a href="stacks.php">Stacks</a>
        </li>
        <li><a href="duct.php">Ducting</a>
        </li>
        <li><a href="pipe.php">Pipe</a>
        </li>
        <li><a href="angle.php">Steel Angels</a>
        </li>
        <li><a href="beam.php">Steel Beams</a>
        </li>
    </ul>
</div>
