<?php
    $service=1;
    $title="Ducting";
    include "header.php";
?>
						<div class="row">
							<div class="inner-content">
								<div class="row">
									<div class="col-md-3">
                                        <?php include "sidemenu.php";?>
									</div>
									<div class="col-md-9">
										<div class="single-description">
											<h1>Ducting</h1>
											<img src="img/duct.jpg" alt="">
											<p>Synergistically syndicate fully tested experiences without web-enabled portals. Appropriately transform economically sound collaboration and idea-sharing via go forward strategic theme areas. Monotonectally empower innovative users without state of the art sources. Energistically fabricate fully tested markets via covalent functionalities. Assertively utilize 2.0 leadership and interoperable relationships.</p>

											<p>
											Quickly visualize long-term high-impact supply chains through vertical expertise. Dynamically impact low-risk high-yield niche markets for clicks-and-mortar growth strategies. Dynamically impact leveraged innovation with granular networks. Seamlessly morph an expanded array of e-tailers after innovative bandwidth. Energistically formulate emerging information after virtual internal or "organic" sources.

											Credibly conceptualize maintainable.
											</p>
											<h2>Hi-Performance</h2>
											<p>Synergistically syndicate fully tested experiences without web-enabled portals. Appropriately transform economically sound collaboration and idea-sharing via go forward strategic theme 
											</p>
											<h2>Pure Steel</h2>
											<p>Synergistically syndicate fully tested experiences without web-enabled portals. Appropriately transform economically sound collaboration and idea-sharing via go forward strategic theme 
											</p>
											<h2>Antifungal Protected</h2>
											<p>Synergistically syndicate fully tested experiences without web-enabled portals. Appropriately transform economically sound collaboration and idea-sharing via go forward strategic theme 
											</p>
											<h2>Sun Heat Protected</h2>
											<p>Synergistically syndicate fully tested experiences without web-enabled portals. Appropriately transform economically sound collaboration and idea-sharing via go forward strategic theme 
											</p>
											<h2>Disaster Protected</h2>
											<p>Synergistically syndicate fully tested experiences without web-enabled portals. Appropriately transform economically sound collaboration and idea-sharing via go forward strategic theme 
											</p>
										</div>
									</div>
								</div>
							</div>
							<!--inner content -->
						</div>
						<!--section row -->

<?php
    include "footer.php";
?>
<style>
.single-description{
    text-align: justify;
    text-justify: inter-word;

}
</style>
